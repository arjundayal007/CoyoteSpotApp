//
//  MasterViewController.m
//  CoyoteSpot
//
//  Created by Shashi Dayal on 12/30/16.
//  Copyright © 2016 RoboChaps. All rights reserved.
//

#import "ViewController.h"

@interface MasterViewController () <MKMapViewDelegate> {
    
}

@end
@implementation MasterViewController





- (void)viewDidLoad
{
    [super viewDidLoad];
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
