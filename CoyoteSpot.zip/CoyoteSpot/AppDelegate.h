//
//  AppDelegate.h
//  CoyoteSpot
//
//  Created by Shashi Dayal on 12/30/16.
//  Copyright © 2016 RoboChaps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

